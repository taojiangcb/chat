"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Commands_1 = require("chatcommon/src/Commands");
class WatchCommand extends Commands_1.SimpleCommand {
    constructor() {
        super();
    }
    receiver(protocol, sock) {
    }
}
exports.WatchCommand = WatchCommand;
//# sourceMappingURL=WatchCommand.js.map