"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Commands_1 = require("chatcommon/src/Commands");
class MessageCommon extends Commands_1.SimpleCommand {
    constructor() {
        super();
    }
    receiver(protocol, sock) { }
}
exports.MessageCommon = MessageCommon;
//# sourceMappingURL=MessageCommon.js.map