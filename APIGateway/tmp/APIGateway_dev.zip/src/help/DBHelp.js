"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class PlatRedis {
}
exports.platRedis = new PlatRedis();
//# sourceMappingURL=DBHelp.js.map