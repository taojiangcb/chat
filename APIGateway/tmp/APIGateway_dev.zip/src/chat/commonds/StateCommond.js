"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Commands_1 = require("../Commands");
class StateCommond extends Commands_1.SimpleCommand {
    constructor() { super(); }
}
exports.StateCommond = StateCommond;
//# sourceMappingURL=StateCommond.js.map