"use strict";
//# sourceMappingURL=IProtocol.js.map